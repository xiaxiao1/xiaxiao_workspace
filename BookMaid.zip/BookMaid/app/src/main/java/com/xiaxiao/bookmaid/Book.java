package com.xiaxiao.bookmaid;

/**
 * Created by xiaxi on 2016/11/2.
 */
public class Book {
    String name;

    public Book(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
